﻿using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using UserDBManagement;

namespace UserDBManagement
{
    public class DBService : IDisposable
    {
        private Class1 classEsim; //TODO need to remove

        protected string ConnectionString { get; set; }
        private SqlConnection _Connection;
        public IConfiguration Configuration { get; private set; }
        private int _TransCount;

        static string CachedConnectionString;
        public DBService(IConfiguration configuration)
        {
            this.Configuration = configuration;
            if (CachedConnectionString == null)
            {
                var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json", true, true);
                CachedConnectionString = builder.Build().GetSection("ConnectionStrings").GetSection("Conn").Value;
            }
            this.ConnectionString = CachedConnectionString;
        }
        public Class1 Class1
        {
            get
            {
                if (this.classEsim == null)
                {
                    this.classEsim = new Class1(this);
                }
                return this.classEsim;
            }
        }

        public SqlConnection Connection
        {
            get
            {
                if (this._Connection == null)
                {
                    var conn = new SqlConnection(this.ConnectionString);
                    conn.Open();
                    this._Connection = conn;
                    this._TransCount = 0;
                }
                return this._Connection;
            }
        }

        ~DBService()
        {
            Dispose(false);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            { // release other disposable objects  
                if (this.Connection != null)
                {
                    if (ActiveTrans())
                    {
                        RollBackTrans();
                    }
                    this.Connection.Close();
                }
            }
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public void BeginTrans()
        {
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.Connection;
                cmd.CommandText = "BEGIN TRAN";
                cmd.ExecuteNonQuery();
            }
            this._TransCount += 1;
        }

        public async Task BeginTransAsync()
        {
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.Connection;
                cmd.CommandText = "BEGIN TRAN";
                await cmd.ExecuteNonQueryAsync();
            }
            this._TransCount += 1;
        }

        public void CommitTrans()
        {
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.Connection;
                cmd.CommandText = "COMMIT TRAN";
                cmd.ExecuteNonQuery();
            }
            this._TransCount -= 1;
        }

        public async Task CommitTransAsync()
        {
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.Connection;
                cmd.CommandText = "COMMIT TRAN";
                await cmd.ExecuteNonQueryAsync();
            }
            this._TransCount -= 1;
        }

        public void RollBackTrans()
        {
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.Connection;
                cmd.CommandText = " IF @@TRANCOUNT > 0 ROLLBACK TRAN; "
                                + " SET TRANSACTION ISOLATION LEVEL READ COMMITTED;";
                cmd.ExecuteNonQuery();
            }
            this._TransCount = 0;
        }

        public async Task RollBackTransAsync()
        {
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.Connection;
                cmd.CommandText = " IF @@TRANCOUNT > 0 ROLLBACK TRAN; "
                                + " SET TRANSACTION ISOLATION LEVEL READ COMMITTED;";
                await cmd.ExecuteNonQueryAsync();
            }
            this._TransCount = 0;
        }

        public bool ActiveTrans()
        {
            return this._TransCount > 0;
        }
    }

}

﻿using Microsoft.Extensions.Configuration;
using System;
using System.Data.SqlClient;
using System.Threading.Tasks;
using UserManagement.DAL;

namespace UserManagement
{
    public class DBService : IDisposable
    {
        private UsersRepository usersRepository; 
        private UsersDataRepository usersDataRepository; 

        protected string ConnectionString { get; set; }
        private SqlConnection _Connection;
        public IConfiguration Configuration { get; private set; }
        private int _TransCount;

        static string CachedConnectionString;

        public DBService(IConfiguration configuration)
        {
            this.Configuration = configuration;
            if (CachedConnectionString == null)
            {
                CachedConnectionString = this.Configuration.GetConnectionString("Conn");
            }
            this.ConnectionString = CachedConnectionString;
        }

        public UsersDataRepository UsersDataRepository
        {
            get
            {
                if (this.usersDataRepository == null)
                {
                    this.usersDataRepository = new UsersDataRepository(this);
                }
                return this.usersDataRepository;
            }
        }

        public UsersRepository UsersRepository
        {
            get
            {
                if (this.usersRepository == null)
                {
                    this.usersRepository = new UsersRepository(this);
                }
                return this.usersRepository;
            }
        }

        public SqlConnection Connection
        {
            get
            {
                if (this._Connection == null)
                {
                    var conn = new SqlConnection(this.ConnectionString);
                    conn.Open();
                    this._Connection = conn;
                    this._TransCount = 0;
                }
                return this._Connection;
            }
        }

        ~DBService()
        {
            Dispose(false);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            { // release other disposable objects  
                if (this.Connection != null)
                {
                    if (ActiveTrans())
                    {
                        RollBackTrans();
                    }
                    this.Connection.Close();
                }
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public void BeginTrans()
        {
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.Connection;
                cmd.CommandText = "BEGIN TRAN";
                cmd.ExecuteNonQuery();
            }
            this._TransCount += 1;
        }

        public async Task BeginTransAsync()
        {
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.Connection;
                cmd.CommandText = "BEGIN TRAN";
                await cmd.ExecuteNonQueryAsync();
            }
            this._TransCount += 1;
        }

        public void CommitTrans()
        {
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.Connection;
                cmd.CommandText = "COMMIT TRAN";
                cmd.ExecuteNonQuery();
            }
            this._TransCount -= 1;
        }

        public async Task CommitTransAsync()
        {
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.Connection;
                cmd.CommandText = "COMMIT TRAN";
                await cmd.ExecuteNonQueryAsync();
            }
            this._TransCount -= 1;
        }

        public void RollBackTrans()
        {
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.Connection;
                cmd.CommandText = " IF @@TRANCOUNT > 0 ROLLBACK TRAN; "
                                + " SET TRANSACTION ISOLATION LEVEL READ COMMITTED;";
                cmd.ExecuteNonQuery();
            }
            this._TransCount = 0;
        }

        public async Task RollBackTransAsync()
        {
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.Connection;
                cmd.CommandText = " IF @@TRANCOUNT > 0 ROLLBACK TRAN; "
                                + " SET TRANSACTION ISOLATION LEVEL READ COMMITTED;";
                await cmd.ExecuteNonQueryAsync();
            }
            this._TransCount = 0;
        }

        public bool ActiveTrans()
        {
            return this._TransCount > 0;
        }
    }

}

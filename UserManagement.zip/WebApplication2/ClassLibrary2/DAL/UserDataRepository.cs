﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserManagement.Models;
using UserManagement.Models.Enums;

namespace UserManagement.DAL
{
    public class UsersDataRepository
    {
        private readonly DBService DBService;

        public UsersDataRepository(DBService dBService)
        {
            this.DBService = dBService;
        }

        //User get also their closed information
        public async Task<UserData> GetUserData(string email, string password)
        {
            await CheckUserExistence(email, password);

            var data = new List<Data>();

            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = email;

                cmd.CommandText = "select fDATA, fOPEN \r\n"
                                + "from USERSDATA \r\n"
                                + "where fEMAIL = @Email and fREMOVED = " + (byte)UserRemovedState.NotRemoved;

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    var ordinalData = reader.GetOrdinal("fDATA");
                    var ordinalIsOpen = reader.GetOrdinal("fOPEN");

                    while (await reader.ReadAsync())
                    {
                        data.Add(new Data()
                        {
                            Info = reader.GetString(ordinalData),
                            IsOpen = reader.GetByte(ordinalIsOpen) == (byte)IsOpen.open
                        });
                    }
                }
            }
            return new UserData() { Email = email, Data = data };
        }

        //User get their data by title
        public async Task<string> GetUserDataByTitle(string email, string password, string title)
        {
            await CheckUserExistence(email, password);

            var data = "";
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = email;
                cmd.Parameters.Add("@Title", SqlDbType.NVarChar).Value = title;

                cmd.CommandText = "select fDATA \r\n"
                                + "from USERSDATA \r\n"
                                + "where fEMAIL = @Email and fTITLE = @Title and fREMOVED = " + (byte)UserRemovedState.NotRemoved;

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    var ordinalData = reader.GetOrdinal("fDATA");

                    if (await reader.ReadAsync())
                    {
                        data = reader.GetString(ordinalData);
                    }
                }
            }
            return data;
        }

        //Admin user can get all users data but not get users closed data
        public async Task<List<UserData>> GetAllUsersData(string email, string password)
        {
            await ValidateAdminUser(email, password);

            var usersData = new List<UserData>();
            var usersDataByEmail = new Dictionary<string, List<Data>>();

            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = email;
                cmd.CommandText = "select fEMAIL, fDATA \r\n"
                                + "from USERSDATA \r\n"
                                + "where (fEMAIL = @Email or fOPEN = " + (byte)IsOpen.open + ") \r\n "
                                + "          and fREMOVED = " + (byte)UserRemovedState.NotRemoved;

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    var ordinalEmail = reader.GetOrdinal("fEMAIL");
                    var ordinalData = reader.GetOrdinal("fDATA");

                    while (await reader.ReadAsync())
                    {
                        var userEmail = reader.GetString(ordinalEmail);
                        if (!usersDataByEmail.ContainsKey(userEmail))
                        {
                            usersDataByEmail.Add(email, new List<Data>());
                        }
                        usersDataByEmail[email].Add(new Data()
                        {
                            Info = reader.GetString(ordinalData),
                            IsOpen = true
                        });
                    }
                }
            }
            foreach (var key in usersDataByEmail.Keys)
            {
                usersData.Add(new UserData()
                {
                    Email = key,
                    Data = usersDataByEmail[key]
                });
            }
            return usersData;
        }

        public async Task<UserData> GetRemovedUserData(string email, string password)
        {
            await CheckUserExistence(email, password);

            var data = new List<Data>();
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = email;

                cmd.CommandText = "select fDATA, fOPEN \r\n"
                                + "from USERSDATA \r\n"
                                + "where fEMAIL = @Email and fREMOVED = " + (byte)UserRemovedState.Removed +" \r\n";

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    var ordinalData = reader.GetOrdinal("fDATA");
                    var ordinalIsOpen = reader.GetOrdinal("fOPEN");

                    while (await reader.ReadAsync())
                    {
                        data.Add(new Data()
                        {
                            Info = reader.GetString(ordinalData),
                            IsOpen = reader.GetByte(ordinalIsOpen) == (byte)IsOpen.open
                        });
                    }
                }
            }
            return new UserData() { Email = email, Data = data };
        }
        
        public async Task AddUserData(string email, string password, string data, string title, bool isOpen)
        {
            await CheckUserExistence(email, password);

            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = email;
                cmd.Parameters.Add("@Title", SqlDbType.NVarChar).Value = title;
                cmd.Parameters.Add("@Data", SqlDbType.NVarChar).Value = data;
                cmd.Parameters.Add("@IsOpen", SqlDbType.TinyInt).Value = isOpen ? (byte)IsOpen.open : (byte)IsOpen.close;

                cmd.CommandText = "insert USERSDATA (fEMAIL, fTITLE, fOPEN, fREMOVED, fDATA) \r\n"
                                + "          values (@Email, @Title, @IsOpen, " + (byte)UserRemovedState.NotRemoved + ", @Data)";
                await cmd.ExecuteNonQueryAsync();
            }
        }

        public async Task ChangeIsOpenState(string email, string password, string title, bool isOpen)
        {
            await CheckUserExistence(email, password);

            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = email;
                cmd.Parameters.Add("@Title", SqlDbType.NVarChar).Value = title;
                cmd.Parameters.Add("@IsOpen", SqlDbType.TinyInt).Value = isOpen ? (byte)IsOpen.open : (byte)IsOpen.close; 

                cmd.CommandText = "update USERSDATA \r\n"
                                + "set fOPEN = @IsOpen \r\n"
                                + "where fEMAIL = @Email and fTITLE = @Title";

                await cmd.ExecuteNonQueryAsync();
            }
        }

        public async Task RestoreDataByTitle(string email, string password, string title)
        {
            await CheckUserExistence(email, password);

            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = email;
                cmd.Parameters.Add("@Title", SqlDbType.NVarChar).Value = title;

                cmd.CommandText = "update USERSDATA \r\n"
                                + "set fREMOVED = " + (byte)UserRemovedState.NotRemoved + " \r\n"
                                + "where fEMAIL = @Email and fTITLE = @Title";

                await cmd.ExecuteNonQueryAsync();

            }
        }

        public async Task DeleteDataByTitle(string email, string password, string title, bool isFullDelete)
        {
            await CheckUserExistence(email, password);

            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = email;
                cmd.Parameters.Add("@Title", SqlDbType.NVarChar).Value = title;

                if (isFullDelete)
                {
                    cmd.CommandText = "delete from USERSDATA \r\n"
                                    + "where fEMAIL = @Email and fTITLE = @Title";
                    await cmd.ExecuteNonQueryAsync();
                }
                else
                {
                    cmd.CommandText = "update USERSDATA \r\n"
                                    + "set fREMOVED = " + (byte)UserRemovedState.Removed + "\r\n"
                                    + "where fEMAIL = @Email and fTITLE = @Title";

                    await cmd.ExecuteNonQueryAsync();
                }
            }
        }

        private async Task ValidateAdminUser(string email, string password)
        {
            var isAdminUser = false;
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.CommandText = "select us.fSTATE as State \r\n"
                                + "from USERSTATES us \r\n"
                                + "   join USERS u on us.fEMAIL = u.fEMAIL \r\n"
                                + "where u.fEMAIL = @Email and u.fPASSWORD = @Password";

                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = email;
                cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = password;

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    if (await reader.ReadAsync())
                    {
                        isAdminUser = reader.GetByte(reader.GetOrdinal("State")) == (byte)UserState.Admin;
                    }
                }
            }

            if (!isAdminUser)
            {
                throw new Exception("User is not admin");
            }
        }

        private async Task CheckUserExistence(string email, string password)
        {
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = email;
                cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = password;

                cmd.CommandText = "if exists(select * \r\n"
                                 + "         from USERS \r\n"
                                 + "         where fEMAIL = @Email and fPASSWORD = @Password) \r\n"
                                 + "    select 1 \r\n"
                                 + "else \r\n"
                                 + "    select 0";

                if (Convert.ToInt16(await cmd.ExecuteScalarAsync()) == 0)
                {
                    throw new Exception("Incorrect email or password");
                }
            }
        }
    }
}

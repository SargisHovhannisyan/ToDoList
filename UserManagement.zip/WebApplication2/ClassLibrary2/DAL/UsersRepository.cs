﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserManagement.Models;
using UserManagement.Models.Enums;

namespace UserManagement.DAL
{
    public class UsersRepository
    {
        private readonly DBService DBService;

        public UsersRepository(DBService dBService)
        {
            this.DBService = dBService;
        }
        public async Task<List<UserWithRemovedState>> GetUsers(string email, string password)
        {
            if (!await ValidateAdminUser(email, password))
            {
                throw new Exception("Only admin user can add users");
            }
            var users = new List<UserWithRemovedState>();
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.CommandText = "select fEMAIL, fNAME, fPASSWORD, fREMOVED \r\n"
                                + "from USERS";
                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    var ordinalEmail = reader.GetOrdinal("fEMAIL");
                    var ordinalName = reader.GetOrdinal("fNAME");
                    var ordinalPassword = reader.GetOrdinal("fPASSWORD");
                    var ordinalRemovedState = reader.GetOrdinal("fREMOVED");

                    while (await reader.ReadAsync())
                    {
                        users.Add(new UserWithRemovedState()
                        {
                            Email = reader.GetString(ordinalEmail),
                            Name = reader.GetString(ordinalName),
                            Password = reader.GetString(ordinalPassword),
                            isRemoved = reader.GetByte(ordinalRemovedState) == (byte)UserRemovedState.Removed ? true : false

                        });
                    }
                }
            }
            return users;
        }

        public async Task AddUser(string email, string password, User user)
        {
            if (!await ValidateAdminUser(email, password))
            {
                throw new Exception("Only admin user can add users");
            }

            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.CommandText = "insert into USERS (fEMAIL, fNAME, fPASSWORD, fREMOVED) \r\n"
                                + "            values(@Email, @Name, @Password, @Removed)";

                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = user.Email;
                cmd.Parameters.Add("@Name", SqlDbType.NVarChar).Value = user.Name;
                cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = user.Password;
                cmd.Parameters.Add("@Removed", SqlDbType.TinyInt).Value = (byte)UserRemovedState.NotRemoved;

                await cmd.ExecuteNonQueryAsync();

            }

            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.CommandText = "insert into USERSTATES (fEMAIL, fSTATE) \r\n"
                               + "            values(@Email, @State)";
                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = user.Email;
                cmd.Parameters.Add("@State", SqlDbType.TinyInt).Value = (byte)UserState.User;

                await cmd.ExecuteNonQueryAsync();

            }
        }

        public async Task DeleteUser(string email, string password, string userEmail, bool isFullDelete)
        {
            if (!await ValidateAdminUser(email, password))
            {
                throw new Exception("Only admin user can delete users");
            }
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = userEmail;

                if (isFullDelete)
                {
                    cmd.CommandText = "delete from USERS \r\n"
                                    + "where fEMAIL = @Email";
                    await cmd.ExecuteNonQueryAsync();

                    cmd.CommandText = "delete from USERSTATES \r\n"
                                    + "where fEMAIL = @Email";
                    await cmd.ExecuteNonQueryAsync();

                    cmd.CommandText = "delete from USERSDATA \r\n"
                                    + "where fEMAIL = @Email";
                    await cmd.ExecuteNonQueryAsync();
                }
                else
                {
                    cmd.Parameters.Add("@RemovedState", SqlDbType.TinyInt).Value = (byte)UserRemovedState.Removed;

                    cmd.CommandText = "update USERS \r\n"
                                    + "set fREMOVED = @RemovedState \r\n"
                                    + "where fEMAIL = @Email";
                    await cmd.ExecuteNonQueryAsync();

                    cmd.CommandText = "update USERSDATA \r\n"
                                    + "set fREMOVED = @RemovedState \r\n"
                                    + "where fEMAIL = @Email";
                    await cmd.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task RestoreUser(string email, string password, string userEmail)
        {
            if (!await ValidateAdminUser(email, password))
            {
                throw new Exception("Only admin user can restore users");
            }

            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = userEmail;
                cmd.Parameters.Add("@RemovedState", SqlDbType.TinyInt).Value = (byte)UserRemovedState.NotRemoved;

                cmd.CommandText = "update USERS \r\n"
                                + "set fREMOVED = @RemovedState \r\n"
                                + "where fEMAIL = @Email";
                await cmd.ExecuteNonQueryAsync();

                cmd.CommandText = "update USERSDATA \r\n"
                               + "set fREMOVED = @RemovedState \r\n"
                               + "where fEMAIL = @Email";
                await cmd.ExecuteNonQueryAsync();
            }
        }

        public async Task ChangeUserState(string email, string password, string userEmail, UserState state)
        {
            if (!await ValidateAdminUser(email, password))
            {
                throw new Exception("Only admin user can change users state");
            }

            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = userEmail;
                cmd.Parameters.Add("@State", SqlDbType.TinyInt).Value = (byte)state;

                cmd.CommandText = "update USERSTATES \r\n"
                                + "set fSTATE = @State \r\n"
                                + "where fEMAIL = @Email";
                await cmd.ExecuteNonQueryAsync();
            }
        }

        private async Task<bool> ValidateAdminUser(string email, string password)
        {
            var isAdminUser = false;
            using (var cmd = new SqlCommand())
            {
                cmd.Connection = this.DBService.Connection;
                cmd.CommandText = "select us.fSTATE as State \r\n"
                                + "from USERSTATES us \r\n"
                                + "   join USERS u on us.fEMAIL = u.fEMAIL \r\n"
                                + "where u.fEMAIL = @Email and u.fPASSWORD = @Password";

                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = email;
                cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = password;

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    if (await reader.ReadAsync())
                    {
                        isAdminUser = reader.GetByte(reader.GetOrdinal("State")) == (byte)UserState.Admin;
                    }
                }
            }
            return isAdminUser;
        }
    }
}

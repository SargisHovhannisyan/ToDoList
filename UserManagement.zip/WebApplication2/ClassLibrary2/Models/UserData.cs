﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserManagement.Models.Enums;

namespace UserManagement.Models
{
    public class UserData
    {
        public string Email { get; set; }
        public List<Data> Data { get; set; }   
    }

    public class Data
    {
        public string Info { get; set; }
        public bool IsOpen { get; set; }
    }
}

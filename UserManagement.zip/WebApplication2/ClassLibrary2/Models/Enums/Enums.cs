﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserManagement.Models.Enums
{
    public enum UserRemovedState
    {
        NotRemoved = 0,
        Removed = 1
    }

    public enum UserState
    {
        User = 0,
        Admin = 1
    }

    public enum IsOpen
    {
        open = 0,
        close = 1
    }
}

--- USERS TABLE
if exists (select *
		   from sys.objects 
		   where object_id = object_id(N'[dbo].[USERS]') and type = N'U')
	drop table [dbo].[USERS] 
go

create table USERS(
    fEMAIL          nvarchar(250)     not null,
    fNAME           nvarchar(50)      not null,
    fPASSWORD       nvarchar(50)      not null,
	fREMOVED        tinyint           not null);

create unique clustered index USERS_PK on USERS(fEMAIL);

---- USER STATES
if exists (select *
		   from sys.objects 
		   where object_id = object_id(N'[dbo].[USERSTATES]') and type = N'U')
	drop table [dbo].[USERSTATES] 
go

create table USERSTATES(
    fEMAIL          nvarchar(250)     not null,
    fSTATE          tinyint           not null);

create unique clustered index USERSTATES_PK on USERSTATES(fEMAIL);

--- USERS DATA
if exists (select *
		   from sys.objects 
		   where object_id = object_id(N'[dbo].[USERSDATA]') and type = N'U')
	drop table [dbo].[USERSDATA] 
go

create table USERSDATA(
    fEMAIL          nvarchar(250)     not null,
	fTITLE          nvarchar(100)     not null,
    fOPEN           tinyint			  not null,
	fREMOVED        tinyint           not null,
	fDATA           nvarchar(max)     not null);

create unique clustered index USERSDATA_PK on USERSDATA(fEMAIL, fTITLE);

---default admin user
insert into USERS(fEMAIL, fNAME, fPASSWORD, fREMOVED)
values('admin@imagenomic.com','admin','admin', 0)

---default admin user state
insert into USERSTATES(fEMAIL, fSTATE)
values('admin@imagenomic.com', 1)
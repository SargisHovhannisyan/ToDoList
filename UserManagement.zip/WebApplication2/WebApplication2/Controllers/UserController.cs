﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using UserManagement;
using UserManagement.Models;
using UserManagement.Models.Enums;

namespace UserManagementService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private DBService dBService;

        public UserController(DBService dBService)
        {
            this.dBService = dBService;
        }
        
        // GET Users
        [HttpGet("Users")]
        public async Task<List<UserWithRemovedState>> Users(string email, string password)
        {
            return await this.dBService.UsersRepository.GetUsers(email, password);
        }
        
        // POST Users
        [HttpPost("User")]
        public async Task Users(string email, string password, User user)
        {
             await this.dBService.UsersRepository.AddUser(email, password, user);
        }

        // POST Restore User
        [HttpPost("RestoreUser")]
        public async Task RestoreUser(string email, string password, string userEmail)
        {
             await this.dBService.UsersRepository.RestoreUser(email, password, userEmail);
        }


        // POST Change User State
        [HttpPost("ChangeUserState")]
        public async Task ChangeUserState(string email, string password, string userEmail, UserState state)
        {
            await this.dBService.UsersRepository.ChangeUserState(email, password, userEmail, state);
        }
        
        // DELETE Delete User
        [HttpDelete("Users")]
        public async Task Users(string email, string password, string userEmail, bool isFullDelete)
        {
            await this.dBService.UsersRepository.DeleteUser(email, password, userEmail, isFullDelete);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using UserManagement;
using UserManagement.Models;
using UserManagement.Models.Enums;

namespace UserManagementService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersDataController : ControllerBase
    {
        private DBService dBService;

        public UsersDataController(DBService dBService)
        {
            this.dBService = dBService;
        }
        
        //Get one user all data
        [HttpGet("UserData")]
        public async Task<UserData> UserData(string email, string password)
        {
            return await this.dBService.UsersDataRepository.GetUserData(email, password);
        }

        //Get one user data by title
        [HttpGet("UserDataByTitle")]
        public async Task<string> UserDataByTitle(string email, string password, string title)
        {
            return await this.dBService.UsersDataRepository.GetUserDataByTitle(email, password, title);
        }
        
        //Get all user all data
        [HttpGet("AllUsersData")]
        public async Task<List<UserData>> AllUsersData(string email, string password)
        {
            return await this.dBService.UsersDataRepository.GetAllUsersData(email, password);
        }
        
        //Get one user removed data 
        [HttpGet("UserRemovedData")]
        public async Task<UserData> UserRemovedData(string email, string password)
        {
            return await this.dBService.UsersDataRepository.GetRemovedUserData(email, password);
        }
      
        // POST Add user Data
        [HttpPost("UserData")]
        public async Task UserData(string email, string password, string data, string title, bool isOpen)
        {
            await this.dBService.UsersDataRepository.AddUserData(email, password, data, title, isOpen);
        }

        // POST change user data isOpen state
        [HttpPost("IsOpenStateInUserData")]
        public async Task UserDataIsOpenState(string email, string password, string title, bool isOpen)
        {
            await this.dBService.UsersDataRepository.ChangeIsOpenState(email, password, title, isOpen);
        } 
        
        // POST change user data isOpen state
        [HttpPost("RestoreUserDataByTitle")]
        public async Task RestoreUserDataByTitle(string email, string password, string title)
        {
            await this.dBService.UsersDataRepository.RestoreDataByTitle(email, password, title);
        }
        
        [HttpDelete("UserDataByTitle")]
        public async Task UserDataByTitle(string email, string password, string title, bool isFullDelete)
        {
            await this.dBService.UsersDataRepository.DeleteDataByTitle(email, password, title, isFullDelete);
        }
    }
}
